import React, { useState } from 'react';
import './App.css';

// Компоненты
import Header from './components/Header';
import Footer from './components/Footer';
import Menu from './components/Menu';
import Content from './components/Content';

// Данные для лабораторных работ
const labWorks = [
  { id: 1, title: '1. Введение. История развития frontend', Content: <><p>Задание:</p><p>1. Реализовать скрипт, который уведомит о полной загрузке страницы</p><p>2. Реализовать кнопку счетчик, которая будет увеличивать счетчик на "1" и вывести его значение на страницу (button onclick)</p><p>3. Реализовать кнопку счетчик, которая будет уменьшать счетчик на "1" реализовать с помощью listener click</p><p>4. Реализовать форму аутентификации пользователя</p> </>},
  { id: 2, title: '2. Основы React. Работа с объектами JS. Часть 1', Content: <><p>Задание:</p><p>1. Создать "Hello World" приложение на основе React.</p><p>2. Для создания можно использовать create-react-app или vite</p><p>Реализовать компонент кнопку, контейнер и использовать их на странице</p><p>3. Реализовать шаблон страницы и разместить на нем компоненты навигации</p><p>4. Разместить проект в репозиторий в github</p><p>5. Разместить проект в репозиторий в github</p>'</> },
  { id: 3, title: '3. Основы React. Работа с объектами JS. Часть 2', Content: <><p>Задание:</p><p>1. Продолжаем задание "Реализовать шаблон страницы и разместить на нем компоненты навигации" (Можно использовать готовые библиотеки Mui/Bootstrap и тд)</p><p>2. Реализуем компоненты Header, Footer, Menu и Content</p><p>3. В меню выводим список лабораторных работ</p><p>4. В Content  выводим содержимое лабораторной работы </p><p>5. Разместить проект в репозиторий в github</p>'</> },
];

function App() {
  const [selectedLab, setSelectedLab] = useState(labWorks[0]); // По умолчанию первая лаба

  const handleLabSelect = (labId) => {
    const selected = labWorks.find(lab => lab.id === labId);
    setSelectedLab(selected);
  };

  return (
    <div className="app-container">
      <Header title="Мои Лабораторные работы" />

      <div className="main-content">
        <Menu labWorks={labWorks} onLabSelect={handleLabSelect} />
        <Content lab={selectedLab} />
      </div>

      <Footer author="My App" />
    </div>
  );
}

export default App;