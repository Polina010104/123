import React from 'react';

function Content({ lab }) {
  return (
    <div className="content">
      <h2>{lab.title}</h2>
      <div>{lab.Content}</div>
    </div>
  );
}

export default Content;