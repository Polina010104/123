import React from 'react';
import './Footer.css'; 

function Footer({ author }) {
  return (
    <footer className="footer">
      <p>&copy; {new Date().getFullYear()} {author}</p>
    </footer>
  );
}

export default Footer;