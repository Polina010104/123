import React from 'react';
import './Menu.css'; 

function Menu({ labWorks, onLabSelect }) {
  return (
    <nav className="menu">
      <h2>Лабораторные работы</h2>
      <ul>
        {labWorks.map(lab => (
          <li key={lab.id}>
            <button onClick={() => onLabSelect(lab.id)}>{lab.title}</button>
          </li>
        ))}
      </ul>
    </nav>
  );
}

export default Menu;