const express = require('express');
const cors = require('cors');
const app = express();
const port = 8000;

app.use(cors());
app.use(express.json());

app.post('/api/submit', (req, res) => {
  try {
    console.log('Получен запрос на /api/submit');
    console.log('Данные:', req.body);

    const name = req.body.name;
    const email = req.body.email;

    if (!name || !email) {
      console.log('Ошибка: не все поля заполнены');
      return res.status(400).json({ error: 'Пожалуйста, заполните все поля' });
    }

    console.log('Имя:', name);
    console.log('Email:', email);

    res.json({ message: 'Данные успешно получены сервером!' });

  } catch (error) {
    console.error('Ошибка при обработке запроса:', error);
    res.status(500).json({ error: 'Произошла ошибка на сервере' });
  }
});

app.listen(port, () => {
  console.log(`Сервер запущен на порту ${port}`);
});