import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Home from './components/Home';
import About from './components/About';
import Profile from './components/Profile';
import Lab1 from './components/Lab1';
import Lab2 from './components/Lab2';
import Lab3 from './components/Lab3';
import BottomMenu from './components/BottomMenu';
import { CssBaseline, Container } from '@mui/material'; // Импорт остается

function App() {
  return (
    <BrowserRouter>
      <CssBaseline /> {/*  Используем CssBaseline */}
      <Header />
      <Container maxWidth="md">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/lab1" element={<Lab1 />} />
          <Route path="/lab2" element={<Lab2 />} />
          <Route path="/lab3" element={<Lab3 />} />
        </Routes>
      </Container>
      <BottomMenu />
    </BrowserRouter>
  );
}

export default App;