import React from 'react';
import { Typography } from '@mui/material';

function Lab1() {
  return (
    <div>
      <Typography variant="h4">Лабораторная работа 1</Typography>
      <Typography>Содержимое лабораторной работы 1.</Typography>
    </div>
  );
}

export default Lab1;