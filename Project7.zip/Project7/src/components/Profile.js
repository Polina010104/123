import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Grid,
  Paper,
  TextField,
  Button,
} from '@mui/material';

function Profile() {
  const [profileData, setProfileData] = useState({
    name: localStorage.getItem('profileName') || '',
    email: localStorage.getItem('profileEmail') || '',
    bio: localStorage.getItem('profileBio') || '',
  });

  const handleChange = (e) => {
    setProfileData({ ...profileData, [e.target.name]: e.target.value });
  };

  useEffect(() => {
    localStorage.setItem('profileName', profileData.name);
    localStorage.setItem('profileEmail', profileData.email);
    localStorage.setItem('profileBio', profileData.bio);
  }, [profileData]);

  return (
    <Container maxWidth="md">
      <Paper elevation={3} style={{ padding: '20px', marginTop: '20px' }}>
        <Grid container spacing={3} alignItems="center">
          {/* Avatar удален */}
          <Grid item xs={12} md={12}> {/*  Изменили ширину колонки на 12 */}
            <Typography variant="h5">Профиль пользователя</Typography>
            <TextField
              label="Имя"
              fullWidth
              margin="normal"
              name="name"
              value={profileData.name}
              onChange={handleChange}
            />
            <TextField
              label="Email"
              fullWidth
              margin="normal"
              name="email"
              value={profileData.email}
              onChange={handleChange}
            />
            <TextField
              label="О себе"
              fullWidth
              margin="normal"
              name="bio"
              multiline
              rows={4}
              value={profileData.bio}
              onChange={handleChange}
            />
            <Button variant="contained" color="primary">
              Сохранить
            </Button>
          </Grid>
        </Grid>
      </Paper>
    </Container>
  );
}

export default Profile;