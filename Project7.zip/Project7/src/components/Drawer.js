import React from 'react';
import {
  Drawer as MUIDrawer,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
} from '@mui/material';
import { Link } from 'react-router-dom';

function Drawer({ open, onClose }) {
  const labs = [
    { text: 'Лабораторная 1', link: '/lab1' },
    { text: 'Лабораторная 2', link: '/lab2' },
    { text: 'Лабораторная 3', link: '/lab3' },
    // ... другие лабораторные
  ];

  return (
    <MUIDrawer anchor="left" open={open} onClose={onClose}>
      <List>
        {labs.map((lab, index) => (
          <ListItem button key={index} component={Link} to={lab.link} onClick={onClose}>
            <ListItemIcon>
              <span>✉</span> {/* Unicode символ для Inbox */}
            </ListItemIcon>
            <ListItemText primary={lab.text} />
          </ListItem>
        ))}
      </List>
    </MUIDrawer>
  );
}

export default Drawer;