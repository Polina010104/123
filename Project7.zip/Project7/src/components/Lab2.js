import React from 'react';
import { Typography } from '@mui/material';

function Lab1() {
  return (
    <div>
      <Typography variant="h4">Лабораторная работа 2</Typography>
      <Typography>Содержимое лабораторной работы 2.</Typography>
    </div>
  );
}

export default Lab1;