import React from 'react';
import { Typography } from '@mui/material';

function About() {
  return (
    <div>
      <Typography variant="h4">О себе</Typography>
      <Typography>Здесь будет информация обо мне.</Typography>
    </div>
  );
}

export default About;