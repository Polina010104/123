import React, { useState, useEffect } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import { Container, Typography } from '@mui/material';

function MyComponent() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [submittedData, setSubmittedData] = useState(null);

  useEffect(() => {
    // При загрузке компонента пытаемся получить данные из localStorage
    const storedName = localStorage.getItem('name');
    const storedEmail = localStorage.getItem('email');

    if (storedName && storedEmail) {
      setSubmittedData({ name: storedName, email: storedEmail });
    }
  }, []);

  const handleSubmit = () => {
    if (!name || !email) {
      alert('Пожалуйста, заполните все поля');
      return;
    }

    // Сохраняем данные в localStorage
    localStorage.setItem('name', name);
    localStorage.setItem('email', email);

    setSubmittedData({ name, email });
    setName('');
    setEmail('');
  };

  return (
    <Container maxWidth="md">
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <h2>Форма</h2>
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Имя"
            variant="outlined"
            fullWidth
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            label="Email"
            variant="outlined"
            fullWidth
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Grid>
        <Grid item xs={12}>
          <Button variant="contained" color="primary" onClick={handleSubmit}>
            Отправить
          </Button>
        </Grid>
        {submittedData && (
          <Grid item xs={12}>
            <Typography variant="h6">Введенные данные:</Typography>
            <Typography>Имя: {submittedData.name}</Typography>
            <Typography>Email: {submittedData.email}</Typography>
          </Grid>
        )}
      </Grid>
    </Container>
  );
}

export default MyComponent;