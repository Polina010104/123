import React, { useContext, useState } from 'react';
import { Link } from 'react-router-dom';
import { ThemeContext } from '../context/ThemeContext';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Switch,
  IconButton,
} from '@mui/material';
import Drawer from './Drawer';

function Header() {
  const { toggleTheme, mode } = useContext(ThemeContext);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const handleDrawerToggle = () => {
    setIsDrawerOpen(!isDrawerOpen);
  };

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            onClick={handleDrawerToggle}
            sx={{ mr: 2 }}
          >
            <span>☰</span> {/* Unicode символ для меню */}
          </IconButton>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Мой сайт
          </Typography>
          <Button color="inherit" component={Link} to="/">
            Главная
          </Button>
          <Button color="inherit" component={Link} to="/about">
            О себе
          </Button>
          <Button color="inherit" component={Link} to="/profile">
            Профиль
          </Button>
          <Switch
            checked={mode === 'dark'}
            onChange={toggleTheme}
            name="themeSwitch"
            inputProps={{ 'aria-label': 'Сменить тему' }}
          />
        </Toolbar>
      </AppBar>

      <Drawer open={isDrawerOpen} onClose={handleDrawerToggle} />
    </>
  );
}

export default Header;