import React, { useState } from 'react';
import './BottomMenu.css';

function BottomMenu() {
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');
  const [showMessage, setShowMessage] = useState(false);

  const handleFeedbackClick = () => {
    setShowFeedbackForm(true);
  };

  const handleCloseFeedbackForm = () => {
    setShowFeedbackForm(false);
  };

  const handleNameChange = (event) => {
    setName(event.target.value);
  };

  const handleMessageChange = (event) => {
    setMessage(event.target.value);
  };

  const handleSubmit = () => {
    // Сохраняем сообщение в localStorage
    const messages = JSON.parse(localStorage.getItem('messages') || '[]');
    const newMessage = {
      name: name,
      message: message,
      timestamp: new Date().toISOString(),
    };
    messages.push(newMessage);
    localStorage.setItem('messages', JSON.stringify(messages));

    // Очищаем форму
    setName('');
    setMessage('');

    // Закрываем форму
    setShowFeedbackForm(false);

    // Показываем сообщение об отправке
    setShowMessage(true);

    // Скрываем сообщение через 3 секунды
    setTimeout(() => {
      setShowMessage(false);
    }, 3000);
  };

  return (
    <>
      <div className="bottom-menu">
        <button className="bottom-menu-button" onClick={handleFeedbackClick}>
          Обратная связь
        </button>
      </div>

      {showFeedbackForm && (
        <div className="feedback-form-overlay">
          <div className="feedback-form">
            <h2>Обратная связь</h2>
            <input
              type="text"
              placeholder="Ваше имя"
              value={name}
              onChange={handleNameChange}
            />
            <textarea
              placeholder="Сообщение"
              value={message}
              onChange={handleMessageChange}
            ></textarea>
            <button onClick={handleCloseFeedbackForm}>Отмена</button>
            <button onClick={handleSubmit}>Отправить</button>
          </div>
        </div>
      )}

      {showMessage && (
        <div className="message-overlay">
          <div className="message-box">
            <p>Сообщение отправлено!</p>
          </div>
        </div>
      )}
    </>
  );
}

export default BottomMenu;