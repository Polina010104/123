import React, { useContext, useEffect } from 'react'; // Добавляем useEffect в импорт
import { ThemeContext } from './ThemeContext';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { incrementCounter, decrementCounter } from './redux/actions/counterActions';
import './App.css';

function Home() {
  useEffect(() => {
    // Этот код будет выполнен при монтировании компонента и каждый раз, когда dependencies (если есть) изменяются.
    document.title = "Главная страница"; // Пример: Изменение заголовка страницы
    // Функция, которая будет вызвана при размонтировании компонента или перед повторным запуском эффекта.
    return () => {
      document.title = "React App"; // Возвращаем стандартный заголовок (или другой по умолчанию).
    };
  }, []); // Пустой массив зависимостей означает, что эффект запустится только один раз при монтировании.
  return (
    <div>
      <h2>Главная страница</h2>
      <p>Добро пожаловать на главную страницу!</p>
    </div>
  );
}

function About() {
  useEffect(() => {
    // Этот код будет выполнен при монтировании компонента и каждый раз, когда dependencies (если есть) изменяются.
    document.title = "О нас"; // Пример: Изменение заголовка страницы
    // Функция, которая будет вызвана при размонтировании компонента или перед повторным запуском эффекта.
    return () => {
      document.title = "React App"; // Возвращаем стандартный заголовок (или другой по умолчанию).
    };
  }, []); // Пустой массив зависимостей означает, что эффект запустится только один раз при монтировании.

  return (
    <div>
      <h2>О нас</h2>
      <p>Информация о нашей компании.</p>
    </div>
  );
}

function Counter() {
  const count = useSelector((state) => state.counter.count); // Получаем count из Redux store
  const dispatch = useDispatch(); // Получаем dispatch функцию

  const handleIncrement = () => {
    dispatch(incrementCounter()); // Отправляем action incrementCounter
  };

  const handleDecrement = () => {
    dispatch(decrementCounter()); // Отправляем action decrementCounter
  };
  useEffect(() => {
    // Этот код будет выполнен при монтировании компонента и каждый раз, когда dependencies (если есть) изменяются.
    document.title = "Счетчик"; // Пример: Изменение заголовка страницы
    // Функция, которая будет вызвана при размонтировании компонента или перед повторным запуском эффекта.
    return () => {
      document.title = "React App"; // Возвращаем стандартный заголовок (или другой по умолчанию).
    };
  }, []); // Пустой массив зависимостей означает, что эффект запустится только один раз при монтировании.

  return (
    <div>
      <h2>Счетчик</h2>
      <p>Счетчик: {count}</p>
      <button onClick={handleIncrement}>Увеличить счетчик</button>
      <button onClick={handleDecrement}>Уменьшить счетчик</button>
    </div>
  );
}

function App() {
  const { theme, toggleTheme } = useContext(ThemeContext);

  return (
    <div className={`App ${theme}`}>
      <Router>
        <header className="App-header">
          <h1>Тема: {theme === 'light' ? 'Светлая' : 'Темная'}</h1>
          <button onClick={toggleTheme}>Переключить тему</button>
          <nav>
            <ul>
              <li>
                <Link to="/">Главная</Link>
              </li>
              <li>
                <Link to="/about">О нас</Link>
              </li>
              <li>
                <Link to="/counter">Счетчик</Link>
              </li>
            </ul>
          </nav>
        </header>

        <div className="App-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/counter" element={<Counter />} />
          </Routes>
        </div>
      </Router>
    </div>
  );
}

export default App;