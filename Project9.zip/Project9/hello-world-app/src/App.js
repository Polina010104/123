import React from 'react'
import PostsList from './components/PostsList'
import './components/PostsList.css'

function App() {
  return (
    <div className="App">
      <PostsList />
    </div>
  )
}

export default App