import React from 'react'
import { useGetPostsQuery } from '../services/postsApi'

const PostsList = () => {
  const { data: posts, isLoading, isError, isFetching } = useGetPostsQuery()
  // isLoading для отображения индикатора загрузки при первой загрузке данных
  if (isLoading) {
    return <div className="spinner">Loading...</div>
  }

  if (isError) {
    return <div className="error">Error loading posts</div>
  }
  // isFetching для отображения индикатора обновления при последующих запросах данных, когда у вас уже есть что отобразить
  return (
    <div>
      {isFetching && <div className="fetching">Updating...</div>}
      <h1>Posts List</h1>
      <ul>
        {posts?.map((post) => (
          <li key={post.id}>
            <h3>{post.title}</h3>
            <p>{post.body}</p>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default PostsList