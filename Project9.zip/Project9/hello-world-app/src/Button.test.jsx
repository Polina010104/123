import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Button from './Button';

describe('Button component', () => {
  // Проверяет, что компонент Button отображает переданный ему текст (children) правильно.
  it('renders button with children', () => {
    // Рендерит компонент Button с текстом "Click me" в качестве children и пустой функцией onClick. 
    // Функция render помещает компонент в виртуальный DOM для тестирования.
    render(<Button onClick={() => {}}>Click me</Button>);
    // Использует screen.getByTestId для поиска элемента в отрендеренном DOM с атрибутом data-testid="button" и проверяет, 
    // что его текстовое содержимое равно "Click me".  `expect` используется для утверждений (assertions) о том, что должно быть правдой.
    expect(screen.getByTestId('button')).toHaveTextContent('Click me');
  });
  // Проверяет, что функция onClick, переданная компоненту Button, вызывается при клике на кнопку
  it('calls onClick when clicked', () => {
    // Создает mock-функцию (функцию-заглушку) с помощью jest.fn(). Mock-функция позволяет отслеживать, как часто она была вызвана.
    const handleClick = jest.fn(); 
    // Рендерит компонент Button, передавая mock-функцию handleClick в качестве обработчика события onClick.
    render(<Button onClick={handleClick}>Click me</Button>);
    // Имитирует клик на элемент с data-testid="button" с помощью fireEvent.
    fireEvent.click(screen.getByTestId('button'));
    // Проверяет, что mock-функция handleClick была вызвана ровно один раз.
    expect(handleClick).toHaveBeenCalledTimes(1);
  });
  // Проверяет, что кнопка становится неактивной (disabled) при передаче пропса (механизма передачи данных от родительского 
  // компонента к дочернему компоненту) disabled={true}
  it('is disabled when disabled prop is true', () => {
    // Рендерит компонент Button с пропсом disabled установленным в true.
    render(<Button onClick={() => {}} disabled>Click me</Button>);
    // Проверяет, что элемент с data-testid="button" имеет атрибут disabled, то есть кнопка неактивна.
    expect(screen.getByTestId('button')).toBeDisabled();
  });
});