import React from 'react';
import './Layout.css';
import { Link } from 'react-router-dom';

function Layout({ children }) {
  return (
    <div className="layout">
      <nav className="navigation">
        <ul>
          <li>
            <Link to="/">Домашняя страница</Link>
          </li>
          <li>
            <Link to="/about">О нас</Link>
          </li>
          <li>
            <Link to="/contact">Контакты</Link>
          </li>
        </ul>
      </nav>
      <main className="main-content">{children}</main>
      <footer className="footer">
        <p>&copy; 2023 My App</p>
      </footer>
    </div>
  );
}

export default Layout;