import React from 'react';
import './App.css';
import Button from './components/Button';
import Container from './components/Container';
import Layout from './components/Layout';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Container>
          <h1>Hello, World!</h1>
          <p>Это мой первый React App.</p>
          <Button onClick={() => alert('Вы нажали на кнопку!')}>Нажми на меня!</Button>
        </Container>
      </Layout>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />
      </Routes>
    </BrowserRouter>
  );
}

function HomePage() {
  return <h2>Домашняя страница</h2>;
}

function AboutPage() {
  return <h2>О нас</h2>;
}

function ContactPage() {
  return <h2>Контакты</h2>;
}

export default App;